package Entity;

public class Coach extends AppUser {

    private String Weight;
    private String Height;

    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
